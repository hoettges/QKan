<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="AllStyleCategories" maxScale="0" minScale="250" labelsEnabled="0" simplifyLocal="1" simplifyAlgorithm="0" readOnly="0" version="3.28.13-Firenze" simplifyDrawingHints="1" symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="1" simplifyDrawingTol="1" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal durationUnit="min" accumulate="0" mode="0" limitMode="0" startExpression="" endExpression="" enabled="0" durationField="" fixedDuration="0" startField="" endField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" extrusionEnabled="0" clamping="Terrain" zoffset="0" showMarkerSymbolInSurfacePlots="0" extrusion="0" symbology="Line" zscale="1" type="IndividualFeatures" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" is_animated="0" name="" clip_to_extent="1" force_rhr="0" type="line" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" pass="0">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="231,113,72,255" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" is_animated="0" name="" clip_to_extent="1" force_rhr="0" type="fill" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" pass="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="231,113,72,255" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="165,81,51,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" is_animated="0" name="" clip_to_extent="1" force_rhr="0" type="marker" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" pass="0">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="231,113,72,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="165,81,51,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" type="singleSymbol" symbollevels="0">
    <symbols>
      <symbol alpha="1" is_animated="0" name="0" clip_to_extent="1" force_rhr="0" type="line" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="MarkerLine" pass="0">
          <Option type="Map">
            <Option value="4" name="average_angle_length" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="average_angle_map_unit_scale" type="QString"/>
            <Option value="MM" name="average_angle_unit" type="QString"/>
            <Option value="3" name="interval" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="interval_map_unit_scale" type="QString"/>
            <Option value="MM" name="interval_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="0" name="offset_along_line" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_along_line_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_along_line_unit" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="true" name="place_on_every_part" type="bool"/>
            <Option value="LastVertex" name="placements" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="1" name="rotate" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol alpha="1" is_animated="0" name="@0@0" clip_to_extent="1" force_rhr="0" type="marker" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleMarker" pass="0">
              <Option type="Map">
                <Option value="180" name="angle" type="QString"/>
                <Option value="square" name="cap_style" type="QString"/>
                <Option value="178,178,178,255" name="color" type="QString"/>
                <Option value="0" name="horizontal_anchor_point" type="QString"/>
                <Option value="bevel" name="joinstyle" type="QString"/>
                <Option value="diagonal_half_square" name="name" type="QString"/>
                <Option value="0,0" name="offset" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                <Option value="MapUnit" name="offset_unit" type="QString"/>
                <Option value="35,35,35,255" name="outline_color" type="QString"/>
                <Option value="solid" name="outline_style" type="QString"/>
                <Option value="0" name="outline_width" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                <Option value="MapUnit" name="outline_width_unit" type="QString"/>
                <Option value="diameter" name="scale_method" type="QString"/>
                <Option value="0.2" name="size" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                <Option value="MapUnit" name="size_unit" type="QString"/>
                <Option value="2" name="vertical_anchor_point" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
        <layer locked="0" enabled="1" class="SimpleLine" pass="0">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="35,35,35,255" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.8" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="5.55112e-17" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" enabled="1" class="SimpleLine" pass="1">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="203,203,203,255" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.4" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option value="offline" name="QFieldSync/action" type="QString"/>
      <Option value="{}" name="QFieldSync/attachment_naming" type="QString"/>
      <Option value="" name="QFieldSync/attribute_editing_locked_expression" type="QString"/>
      <Option value="offline" name="QFieldSync/cloud_action" type="QString"/>
      <Option value="" name="QFieldSync/feature_addition_locked_expression" type="QString"/>
      <Option value="" name="QFieldSync/feature_deletion_locked_expression" type="QString"/>
      <Option value="" name="QFieldSync/geometry_editing_locked_expression" type="QString"/>
      <Option value="{}" name="QFieldSync/photo_naming" type="QString"/>
      <Option value="{}" name="QFieldSync/relationship_maximum_visible" type="QString"/>
      <Option value="30" name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int"/>
      <Option value="1" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="int"/>
      <Option value="0" name="QFieldSync/tracking_measurement_type" type="int"/>
      <Option value="30" name="QFieldSync/tracking_time_requirement_interval_seconds" type="int"/>
      <Option value="0" name="QFieldSync/value_map_button_interface_threshold" type="int"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option value="&quot;leitnam&quot;" type="QString"/>
      </Option>
      <Option value="0" name="embeddedWidgets/count" type="QString"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory backgroundAlpha="255" spacingUnitScale="3x:0,0,0,0,0,0" width="15" spacingUnit="MM" minimumSize="0" penColor="#000000" sizeScale="3x:0,0,0,0,0,0" spacing="5" penWidth="0" diagramOrientation="Up" penAlpha="255" showAxis="1" height="15" labelPlacementMethod="XHeight" opacity="1" backgroundColor="#ffffff" sizeType="MM" rotationOffset="270" lineSizeType="MM" scaleBasedVisibility="0" lineSizeScale="3x:0,0,0,0,0,0" enabled="0" maxScaleDenominator="1e+08" scaleDependency="Area" direction="0" barWidth="5" minScaleDenominator="0">
      <fontProperties strikethrough="0" italic="0" description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0"/>
      <attribute field="" label="" color="#000000" colorOpacity="1"/>
      <axisSymbol>
        <symbol alpha="1" is_animated="0" name="" clip_to_extent="1" force_rhr="0" type="line" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" enabled="1" class="SimpleLine" pass="0">
            <Option type="Map">
              <Option value="0" name="align_dash_pattern" type="QString"/>
              <Option value="square" name="capstyle" type="QString"/>
              <Option value="5;2" name="customdash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
              <Option value="MM" name="customdash_unit" type="QString"/>
              <Option value="0" name="dash_pattern_offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
              <Option value="0" name="draw_inside_polygon" type="QString"/>
              <Option value="bevel" name="joinstyle" type="QString"/>
              <Option value="35,35,35,255" name="line_color" type="QString"/>
              <Option value="solid" name="line_style" type="QString"/>
              <Option value="0.26" name="line_width" type="QString"/>
              <Option value="MM" name="line_width_unit" type="QString"/>
              <Option value="0" name="offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="offset_unit" type="QString"/>
              <Option value="0" name="ring_filter" type="QString"/>
              <Option value="0" name="trim_distance_end" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_end_unit" type="QString"/>
              <Option value="0" name="trim_distance_start" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_start_unit" type="QString"/>
              <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
              <Option value="0" name="use_custom_dash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings zIndex="0" placement="2" priority="0" dist="0" obstacle="0" showAll="1" linePlacementFlags="18">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="pk" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="leitnam" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="schoben" configurationFlags="None">
      <editWidget type="ValueRelation">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowMulti" type="bool"/>
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="" name="Description" type="QString"/>
            <Option value="" name="FilterExpression" type="QString"/>
            <Option value="schnam" name="Key" type="QString"/>
            <Option value="anschlussschaechte_40ba3139_67b9_43cf_9c10_1b62ad11f61b" name="Layer" type="QString"/>
            <Option value="HA-Schächte" name="LayerName" type="QString"/>
            <Option value="spatialite" name="LayerProviderName" type="QString"/>
            <Option value="dbname='demo.sqlite' table=&quot;anschlussschaechte&quot; (geom)" name="LayerSource" type="QString"/>
            <Option value="1" name="NofColumns" type="int"/>
            <Option value="true" name="OrderByValue" type="bool"/>
            <Option value="true" name="UseCompleter" type="bool"/>
            <Option value="schnam" name="Value" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="schunten" configurationFlags="None">
      <editWidget type="ValueRelation">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowMulti" type="bool"/>
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="" name="Description" type="QString"/>
            <Option value="" name="FilterExpression" type="QString"/>
            <Option value="schnam" name="Key" type="QString"/>
            <Option value="anschlussschaechte_40ba3139_67b9_43cf_9c10_1b62ad11f61b" name="Layer" type="QString"/>
            <Option value="HA-Schächte" name="LayerName" type="QString"/>
            <Option value="spatialite" name="LayerProviderName" type="QString"/>
            <Option value="dbname='demo.sqlite' table=&quot;anschlussschaechte&quot; (geom)" name="LayerSource" type="QString"/>
            <Option value="1" name="NofColumns" type="int"/>
            <Option value="true" name="OrderByValue" type="bool"/>
            <Option value="true" name="UseCompleter" type="bool"/>
            <Option value="schnam" name="Value" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="hoehe" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="breite" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="laenge" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="aussendurchmesser" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sohleoben" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sohleunten" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="baujahr" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="haltnam" configurationFlags="None">
      <editWidget type="ValueRelation">
        <config>
          <Option type="Map">
            <Option value="false" name="AllowMulti" type="bool"/>
            <Option value="true" name="AllowNull" type="bool"/>
            <Option value="" name="Description" type="QString"/>
            <Option value="" name="FilterExpression" type="QString"/>
            <Option value="haltnam" name="Key" type="QString"/>
            <Option value="haltungen20161016203756230" name="Layer" type="QString"/>
            <Option value="Haltungen" name="LayerName" type="QString"/>
            <Option value="spatialite" name="LayerProviderName" type="QString"/>
            <Option value="dbname='demo.sqlite' table=&quot;haltungen&quot; (geom) sql=haltungstyp IS NULL or haltungstyp = 'Haltung'" name="LayerSource" type="QString"/>
            <Option value="1" name="NofColumns" type="int"/>
            <Option value="true" name="OrderByValue" type="bool"/>
            <Option value="false" name="UseCompleter" type="bool"/>
            <Option value="haltnam" name="Value" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="urstation" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ursprung" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="anschlusstyp" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lageanschluss" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="teilgebiet" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="strasse" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option value="false" name="IsMultiline" type="bool"/>
            <Option value="false" name="UseHtml" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="profilnam" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="entwart" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="material" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="profilauskleidung" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="innenmaterial" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ks" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="simstatus" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="xschob" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="yschob" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="xschun" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="yschun" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kommentar" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="createdat" configurationFlags="None">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="pk" index="0" name=""/>
    <alias field="leitnam" index="1" name="Bezeichnung"/>
    <alias field="schoben" index="2" name="Anfangsschacht"/>
    <alias field="schunten" index="3" name="Endschacht"/>
    <alias field="hoehe" index="4" name="Profilhöhe"/>
    <alias field="breite" index="5" name="Profilbreite"/>
    <alias field="laenge" index="6" name="Haltungslänge"/>
    <alias field="aussendurchmesser" index="7" name="Außendurchmesser"/>
    <alias field="sohleoben" index="8" name="Sohlhöhe Anfang"/>
    <alias field="sohleunten" index="9" name="Sohlhöhe Ende"/>
    <alias field="baujahr" index="10" name="Baujahr"/>
    <alias field="haltnam" index="11" name="Anschluss an Haltung"/>
    <alias field="urstation" index="12" name="Urstation"/>
    <alias field="ursprung" index="13" name="Ursprung"/>
    <alias field="anschlusstyp" index="14" name="Anschlusstyp"/>
    <alias field="lageanschluss" index="15" name="Lage des Anschlusses"/>
    <alias field="teilgebiet" index="16" name="Teilgebiet"/>
    <alias field="strasse" index="17" name="Straße"/>
    <alias field="profilnam" index="18" name="Profilbezeichnung"/>
    <alias field="entwart" index="19" name="Entwässerungssystem"/>
    <alias field="material" index="20" name="Material"/>
    <alias field="profilauskleidung" index="21" name="Profilauskleidung"/>
    <alias field="innenmaterial" index="22" name="Innenmaterial"/>
    <alias field="ks" index="23" name="Rauheitsbeiwert"/>
    <alias field="simstatus" index="24" name="Planungsstatus"/>
    <alias field="xschob" index="25" name="X Anfang"/>
    <alias field="yschob" index="26" name="Y Anfang"/>
    <alias field="xschun" index="27" name="X Ende"/>
    <alias field="yschun" index="28" name="Y Ende"/>
    <alias field="kommentar" index="29" name="Kommentar"/>
    <alias field="createdat" index="30" name="erstellt"/>
  </aliases>
  <defaults>
    <default field="pk" applyOnUpdate="0" expression=""/>
    <default field="leitnam" applyOnUpdate="0" expression=""/>
    <default field="schoben" applyOnUpdate="0" expression=""/>
    <default field="schunten" applyOnUpdate="0" expression=""/>
    <default field="hoehe" applyOnUpdate="0" expression=""/>
    <default field="breite" applyOnUpdate="0" expression=""/>
    <default field="laenge" applyOnUpdate="0" expression=""/>
    <default field="aussendurchmesser" applyOnUpdate="0" expression=""/>
    <default field="sohleoben" applyOnUpdate="0" expression=""/>
    <default field="sohleunten" applyOnUpdate="0" expression=""/>
    <default field="baujahr" applyOnUpdate="0" expression=""/>
    <default field="haltnam" applyOnUpdate="0" expression=""/>
    <default field="urstation" applyOnUpdate="0" expression=""/>
    <default field="ursprung" applyOnUpdate="0" expression=""/>
    <default field="anschlusstyp" applyOnUpdate="0" expression=""/>
    <default field="lageanschluss" applyOnUpdate="0" expression=""/>
    <default field="teilgebiet" applyOnUpdate="0" expression=""/>
    <default field="strasse" applyOnUpdate="0" expression=""/>
    <default field="profilnam" applyOnUpdate="0" expression=""/>
    <default field="entwart" applyOnUpdate="0" expression=""/>
    <default field="material" applyOnUpdate="0" expression=""/>
    <default field="profilauskleidung" applyOnUpdate="0" expression=""/>
    <default field="innenmaterial" applyOnUpdate="0" expression=""/>
    <default field="ks" applyOnUpdate="0" expression=""/>
    <default field="simstatus" applyOnUpdate="0" expression=""/>
    <default field="xschob" applyOnUpdate="0" expression=""/>
    <default field="yschob" applyOnUpdate="0" expression=""/>
    <default field="xschun" applyOnUpdate="0" expression=""/>
    <default field="yschun" applyOnUpdate="0" expression=""/>
    <default field="kommentar" applyOnUpdate="0" expression=""/>
    <default field="createdat" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint field="pk" exp_strength="0" unique_strength="1" notnull_strength="1" constraints="3"/>
    <constraint field="leitnam" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="schoben" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="schunten" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="hoehe" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="breite" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="laenge" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="aussendurchmesser" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="sohleoben" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="sohleunten" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="baujahr" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="haltnam" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="urstation" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="ursprung" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="anschlusstyp" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="lageanschluss" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="teilgebiet" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="strasse" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="profilnam" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="entwart" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="material" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="profilauskleidung" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="innenmaterial" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="ks" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="simstatus" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="xschob" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="yschob" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="xschun" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="yschun" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="kommentar" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint field="createdat" exp_strength="0" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="pk" exp="" desc=""/>
    <constraint field="leitnam" exp="" desc=""/>
    <constraint field="schoben" exp="" desc=""/>
    <constraint field="schunten" exp="" desc=""/>
    <constraint field="hoehe" exp="" desc=""/>
    <constraint field="breite" exp="" desc=""/>
    <constraint field="laenge" exp="" desc=""/>
    <constraint field="aussendurchmesser" exp="" desc=""/>
    <constraint field="sohleoben" exp="" desc=""/>
    <constraint field="sohleunten" exp="" desc=""/>
    <constraint field="baujahr" exp="" desc=""/>
    <constraint field="haltnam" exp="" desc=""/>
    <constraint field="urstation" exp="" desc=""/>
    <constraint field="ursprung" exp="" desc=""/>
    <constraint field="anschlusstyp" exp="" desc=""/>
    <constraint field="lageanschluss" exp="" desc=""/>
    <constraint field="teilgebiet" exp="" desc=""/>
    <constraint field="strasse" exp="" desc=""/>
    <constraint field="profilnam" exp="" desc=""/>
    <constraint field="entwart" exp="" desc=""/>
    <constraint field="material" exp="" desc=""/>
    <constraint field="profilauskleidung" exp="" desc=""/>
    <constraint field="innenmaterial" exp="" desc=""/>
    <constraint field="ks" exp="" desc=""/>
    <constraint field="simstatus" exp="" desc=""/>
    <constraint field="xschob" exp="" desc=""/>
    <constraint field="yschob" exp="" desc=""/>
    <constraint field="xschun" exp="" desc=""/>
    <constraint field="yschun" exp="" desc=""/>
    <constraint field="kommentar" exp="" desc=""/>
    <constraint field="createdat" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns>
      <column name="pk" hidden="0" width="-1" type="field"/>
      <column name="leitnam" hidden="0" width="-1" type="field"/>
      <column name="schoben" hidden="0" width="-1" type="field"/>
      <column name="schunten" hidden="0" width="-1" type="field"/>
      <column name="hoehe" hidden="0" width="-1" type="field"/>
      <column name="breite" hidden="0" width="-1" type="field"/>
      <column name="laenge" hidden="0" width="-1" type="field"/>
      <column name="aussendurchmesser" hidden="0" width="-1" type="field"/>
      <column name="sohleoben" hidden="0" width="-1" type="field"/>
      <column name="sohleunten" hidden="0" width="-1" type="field"/>
      <column name="baujahr" hidden="0" width="-1" type="field"/>
      <column name="haltnam" hidden="0" width="-1" type="field"/>
      <column name="teilgebiet" hidden="0" width="-1" type="field"/>
      <column name="strasse" hidden="0" width="-1" type="field"/>
      <column name="entwart" hidden="0" width="-1" type="field"/>
      <column name="material" hidden="0" width="-1" type="field"/>
      <column name="profilauskleidung" hidden="0" width="-1" type="field"/>
      <column name="innenmaterial" hidden="0" width="-1" type="field"/>
      <column name="ks" hidden="0" width="-1" type="field"/>
      <column name="anschlusstyp" hidden="0" width="-1" type="field"/>
      <column name="simstatus" hidden="0" width="-1" type="field"/>
      <column name="xschob" hidden="0" width="-1" type="field"/>
      <column name="yschob" hidden="0" width="-1" type="field"/>
      <column name="xschun" hidden="0" width="-1" type="field"/>
      <column name="yschun" hidden="0" width="-1" type="field"/>
      <column name="kommentar" hidden="0" width="-1" type="field"/>
      <column name="createdat" hidden="0" width="-1" type="field"/>
      <column name="profilnam" hidden="0" width="-1" type="field"/>
      <column name="urstation" hidden="0" width="-1" type="field"/>
      <column name="ursprung" hidden="0" width="-1" type="field"/>
      <column name="lageanschluss" hidden="0" width="-1" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>uifilelayout</editorlayout>
  <editable>
    <field name="anschlusstyp" editable="1"/>
    <field name="aussendurchmesser" editable="1"/>
    <field name="baujahr" editable="1"/>
    <field name="breite" editable="1"/>
    <field name="createdat" editable="1"/>
    <field name="deckeloben" editable="1"/>
    <field name="deckelunten" editable="1"/>
    <field name="entwart" editable="1"/>
    <field name="haltnam" editable="1"/>
    <field name="hoehe" editable="1"/>
    <field name="innenmaterial" editable="1"/>
    <field name="kommentar" editable="1"/>
    <field name="ks" editable="1"/>
    <field name="laenge" editable="1"/>
    <field name="lageanschluss" editable="1"/>
    <field name="leitnam" editable="1"/>
    <field name="material" editable="1"/>
    <field name="pk" editable="1"/>
    <field name="profilauskleidung" editable="1"/>
    <field name="profilnam" editable="1"/>
    <field name="qzu" editable="1"/>
    <field name="schoben" editable="1"/>
    <field name="schunten" editable="1"/>
    <field name="simstatus" editable="1"/>
    <field name="sohleoben" editable="1"/>
    <field name="sohleunten" editable="1"/>
    <field name="strasse" editable="1"/>
    <field name="teilgebiet" editable="1"/>
    <field name="ursprung" editable="1"/>
    <field name="urstation" editable="1"/>
    <field name="xschob" editable="1"/>
    <field name="xschun" editable="1"/>
    <field name="yschob" editable="1"/>
    <field name="yschun" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="anschlusstyp" labelOnTop="0"/>
    <field name="aussendurchmesser" labelOnTop="0"/>
    <field name="baujahr" labelOnTop="0"/>
    <field name="breite" labelOnTop="0"/>
    <field name="createdat" labelOnTop="0"/>
    <field name="deckeloben" labelOnTop="0"/>
    <field name="deckelunten" labelOnTop="0"/>
    <field name="entwart" labelOnTop="0"/>
    <field name="haltnam" labelOnTop="0"/>
    <field name="hoehe" labelOnTop="0"/>
    <field name="innenmaterial" labelOnTop="0"/>
    <field name="kommentar" labelOnTop="0"/>
    <field name="ks" labelOnTop="0"/>
    <field name="laenge" labelOnTop="0"/>
    <field name="lageanschluss" labelOnTop="0"/>
    <field name="leitnam" labelOnTop="0"/>
    <field name="material" labelOnTop="0"/>
    <field name="pk" labelOnTop="0"/>
    <field name="profilauskleidung" labelOnTop="0"/>
    <field name="profilnam" labelOnTop="0"/>
    <field name="qzu" labelOnTop="0"/>
    <field name="schoben" labelOnTop="0"/>
    <field name="schunten" labelOnTop="0"/>
    <field name="simstatus" labelOnTop="0"/>
    <field name="sohleoben" labelOnTop="0"/>
    <field name="sohleunten" labelOnTop="0"/>
    <field name="strasse" labelOnTop="0"/>
    <field name="teilgebiet" labelOnTop="0"/>
    <field name="ursprung" labelOnTop="0"/>
    <field name="urstation" labelOnTop="0"/>
    <field name="xschob" labelOnTop="0"/>
    <field name="xschun" labelOnTop="0"/>
    <field name="yschob" labelOnTop="0"/>
    <field name="yschun" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="anschlusstyp" reuseLastValue="0"/>
    <field name="aussendurchmesser" reuseLastValue="0"/>
    <field name="baujahr" reuseLastValue="0"/>
    <field name="breite" reuseLastValue="0"/>
    <field name="createdat" reuseLastValue="0"/>
    <field name="deckeloben" reuseLastValue="0"/>
    <field name="deckelunten" reuseLastValue="0"/>
    <field name="entwart" reuseLastValue="0"/>
    <field name="haltnam" reuseLastValue="0"/>
    <field name="hoehe" reuseLastValue="0"/>
    <field name="innenmaterial" reuseLastValue="0"/>
    <field name="kommentar" reuseLastValue="0"/>
    <field name="ks" reuseLastValue="0"/>
    <field name="laenge" reuseLastValue="0"/>
    <field name="lageanschluss" reuseLastValue="0"/>
    <field name="leitnam" reuseLastValue="0"/>
    <field name="material" reuseLastValue="0"/>
    <field name="pk" reuseLastValue="0"/>
    <field name="profilauskleidung" reuseLastValue="0"/>
    <field name="profilnam" reuseLastValue="0"/>
    <field name="qzu" reuseLastValue="0"/>
    <field name="schoben" reuseLastValue="0"/>
    <field name="schunten" reuseLastValue="0"/>
    <field name="simstatus" reuseLastValue="0"/>
    <field name="sohleoben" reuseLastValue="0"/>
    <field name="sohleunten" reuseLastValue="0"/>
    <field name="strasse" reuseLastValue="0"/>
    <field name="teilgebiet" reuseLastValue="0"/>
    <field name="ursprung" reuseLastValue="0"/>
    <field name="urstation" reuseLastValue="0"/>
    <field name="xschob" reuseLastValue="0"/>
    <field name="xschun" reuseLastValue="0"/>
    <field name="yschob" reuseLastValue="0"/>
    <field name="yschun" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"leitnam"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
